import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { rooms, players } from "@/db/schema";
import { eq } from "drizzle-orm";
import { genCode, genId, genToken, COLORS } from "@/lib/game";
import { loadRoom, publicState } from "@/lib/room";

export async function POST(req: NextRequest) {
  const body = await req.json().catch(() => ({}));
  const action = body.action as string;
  const name = String(body.name || "").trim().slice(0, 16);
  if (!name) return NextResponse.json({ error: "Enter a display name" }, { status: 400 });

  if (action === "create") {
    let code = genCode();
    for (let i = 0; i < 5; i++) {
      const [ex] = await db.select().from(rooms).where(eq(rooms.code, code));
      if (!ex) break; code = genCode();
    }
    const id = genId(), token = genToken();
    await db.insert(rooms).values({ code, hostId: id, phase: "waiting" });
    await db.insert(players).values({ id, roomCode: code, name, color: COLORS[0], token, isHost: true, territory: 0 });
    const loaded = await loadRoom(code);
    return NextResponse.json({ code, playerId: id, token, state: publicState(loaded!.room, loaded!.players, id) });
  }

  if (action === "join") {
    const code = String(body.code || "").trim().toUpperCase();
    if (!/^[A-Z0-9]{6}$/.test(code)) return NextResponse.json({ error: "Invalid room code — use the 6-character code" }, { status: 400 });
    const loaded = await loadRoom(code);
    if (!loaded) return NextResponse.json({ error: "Room not found. Check the code and try again." }, { status: 404 });
    const { room, players: plist } = loaded;
    if (plist.some(p => p.name.toLowerCase() === name.toLowerCase()))
      return NextResponse.json({ error: "That name is already taken in this room — pick another" }, { status: 409 });
    if (plist.length >= 7) return NextResponse.json({ error: "This room is full (7/7 players)" }, { status: 403 });
    if (room.phase === "playing" || room.phase === "countdown")
      return NextResponse.json({ error: "A match is already in progress — wait for it to finish" }, { status: 403 });
    const used = new Set(plist.map(p => p.color));
    const color = COLORS.find(c => !used.has(c)) || COLORS[plist.length % COLORS.length];
    const id = genId(), token = genToken();
    await db.insert(players).values({ id, roomCode: code, name, color, token, isHost: false, territory: 0 });
    const after = await loadRoom(code);
    return NextResponse.json({ code, playerId: id, token, state: publicState(after!.room, after!.players, id) });
  }
  return NextResponse.json({ error: "Unknown action" }, { status: 400 });
}
